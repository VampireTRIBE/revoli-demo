import { Navigate, Route, Routes } from 'react-router-dom';
import { AppLayout } from './layouts/AppLayout';
import { MediaDashboardPage } from './pages/MediaDashboardPage';
import { MediaImportPage } from './pages/MediaImportPage';
import { CreativeDashboardPage } from './pages/CreativeDashboardPage';
import { ConsumerDashboardPage } from './pages/ConsumerDashboardPage';
import { GeoDashboardPage } from './pages/GeoDashboardPage';

export default function App() {
  return <Routes><Route element={<AppLayout />}><Route index element={<Navigate to="/media" replace />} /><Route path="/media" element={<MediaDashboardPage />} /><Route path="/media/import" element={<MediaImportPage />} /><Route path="/creative" element={<CreativeDashboardPage />} /><Route path="/geo" element={<GeoDashboardPage />} /><Route path="/consumer" element={<ConsumerDashboardPage />} /><Route path="/competition" element={<Navigate to="/media?competition=edit-by-ahmed-seddiqi" replace />} /><Route path="*" element={<Navigate to="/media" replace />} /></Route></Routes>;
}
